import sys
import requests
from bs4 import BeautifulSoup
import logging
import tkinter as tk
from tkinter import messagebox, scrolledtext
from tkinter.ttk import Combobox

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Define themes
THEMES = {
    "Default": {"background": "white", "text": "black"},
    "Horimiya": {"background": "#FFE4C4", "text": "black"},  # Light peach
    "Goku Black": {"background": "#2C2C2C", "text": "#FF69B4"},  # Dark gray and pink
    "Ayanokoji": {"background": "#1E1E1E", "text": "#87CEEB"},  # Dark gray and sky blue
}

class WebScraperApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Web Scraper")
        self.root.geometry("600x400")
        
        # Set default theme
        self.set_theme(*THEMES["Default"].values())

        # Create UI elements
        self.create_widgets()

    def create_widgets(self):
        title_label = tk.Label(self.root, text="Web Scraper and Analyzer", font=("Arial", 18))
        title_label.pack(pady=10)

        url_label = tk.Label(self.root, text="Enter URL:")
        url_label.pack(pady=5)

        self.url_input = tk.Entry(self.root, width=50)
        self.url_input.pack(pady=5)

        scrape_button = tk.Button(self.root, text="Scrape and Analyze", command=self.scrape_and_analyze)
        scrape_button.pack(pady=5)

        settings_button = tk.Button(self.root, text="Settings", command=self.open_settings)
        settings_button.pack(pady=5)

        self.summary_text = scrolledtext.ScrolledText(
            self.root, wrap=tk.WORD, height=10, state='normal', bg="white", fg="black"
        )
        self.summary_text.pack(pady=10)

    def set_theme(self, background_color, text_color):
        self.root.config(bg=background_color)
        for widget in self.root.winfo_children():
            widget.config(bg=background_color, fg=text_color)

    def open_settings(self):
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("300x150")

        theme_label = tk.Label(settings_window, text="Select Theme:")
        theme_label.pack(pady=10)

        # Create Combobox for theme selection
        theme_combobox = Combobox(settings_window, values=list(THEMES.keys()), state="readonly")
        theme_combobox.set("Default")  # Default value
        theme_combobox.pack(pady=5)

        def apply_theme():
            selected_theme = theme_combobox.get()
            if selected_theme in THEMES:
                self.set_theme(*THEMES[selected_theme].values())
                settings_window.destroy()
            else:
                messagebox.showwarning("Theme Error", "Selected theme is not valid.")

        apply_button = tk.Button(settings_window, text="Apply", command=apply_theme)
        apply_button.pack(pady=10)

    def scrape_and_analyze(self):
        url = self.url_input.get()
        if url:
            try:
                response = requests.get(url)
                response.raise_for_status()
                content = BeautifulSoup(response.text, 'html.parser').get_text()
                summary, key_concepts = self.summarize_content(content)
                self.summary_text.config(state='normal')
                self.summary_text.delete(1.0, tk.END)  # Clear previous text
                self.summary_text.insert(tk.END, f"Summary:\n\n{summary}\n\nKey Concepts:\n\n{key_concepts}")
                self.summary_text.config(state='disabled')  # Corrected line
            except requests.exceptions.RequestException as e:
                messagebox.showerror("Error", f"Error during scraping: {str(e)}")
                logging.error(f"Error during scraping: {str(e)}")  # Log the error
            except Exception as e:
                messagebox.showerror("Error", f"An unexpected error occurred: {str(e)}")
                logging.error(f"Unexpected error: {str(e)}")  # Log unexpected errors
        else:
            messagebox.showwarning("Input Error", "Please enter a valid URL.")

    def summarize_content(self, content):
        # Example: This is a placeholder for actual content extraction logic
        issue = "Resistance to a key malaria drug detected in African children with severe malaria."
        findings = (
            "10% of children in the study showed partial resistance, meaning the drug took longer than expected "
            "to clear malaria parasites."
        )
        location = "The study was conducted in Jinja, Uganda."
        implications = (
            "This resistance poses a significant threat to malaria treatment and could jeopardize progress in "
            "reducing malaria-related deaths."
        )
        presentation = "The findings were presented at the American Society of Tropical Medicine and Hygiene meeting."

        summary = f"Issue: {issue}\nFindings: {findings}\nLocation: {location}\nImplications: {implications}\nPresentation: {presentation}"

        key_concepts = f"- {issue}\n- {findings}\n- {location}\n- {implications}\n- {presentation}"

        return summary, key_concepts

    def get_tuple_value(self, my_tuple, index, default=None):
        return my_tuple[index] if 0 <= index < len(my_tuple) else default

if __name__ == "__main__":
    root = tk.Tk()
    app = WebScraperApp(root)
    root.mainloop()